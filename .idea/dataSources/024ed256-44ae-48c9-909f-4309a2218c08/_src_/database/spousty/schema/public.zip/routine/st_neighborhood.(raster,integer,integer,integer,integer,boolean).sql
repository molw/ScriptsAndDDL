CREATE FUNCTION st_neighborhood (rast raster, columnx integer, rowy integer, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision[]
	LANGUAGE sql
AS $$
 SELECT _st_neighborhood($1, 1, $2, $3, $4, $5, $6) 
$$
