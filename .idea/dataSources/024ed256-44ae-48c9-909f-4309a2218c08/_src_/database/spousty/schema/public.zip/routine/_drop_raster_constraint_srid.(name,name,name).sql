CREATE FUNCTION _drop_raster_constraint_srid (rastschema name, rasttable name, rastcolumn name) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT _drop_raster_constraint($1, $2, 'enforce_srid_' || $3) 
$$
