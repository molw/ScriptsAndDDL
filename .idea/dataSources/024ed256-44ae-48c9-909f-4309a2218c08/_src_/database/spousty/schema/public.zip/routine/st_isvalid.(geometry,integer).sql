CREATE FUNCTION st_isvalid (geometry, integer) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT (ST_isValidDetail($1, $2)).valid
$$
