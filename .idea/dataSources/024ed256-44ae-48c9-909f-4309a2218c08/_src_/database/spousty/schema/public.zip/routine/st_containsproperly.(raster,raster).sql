CREATE FUNCTION st_containsproperly (rast1 raster, rast2 raster) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT st_containsproperly($1, NULL::integer, $2, NULL::integer) 
$$
