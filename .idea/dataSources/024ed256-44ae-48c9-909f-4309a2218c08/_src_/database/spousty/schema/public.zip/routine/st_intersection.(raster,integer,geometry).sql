CREATE FUNCTION st_intersection (rast raster, band integer, geomin geometry) RETURNS SETOF geomval
	LANGUAGE sql
AS $$
 SELECT st_intersection($3, $1, $2) 
$$
