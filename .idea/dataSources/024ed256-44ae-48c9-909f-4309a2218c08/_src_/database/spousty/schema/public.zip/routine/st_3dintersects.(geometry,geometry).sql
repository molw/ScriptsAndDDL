CREATE FUNCTION st_3dintersects (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_3DIntersects($1, $2)
$$
