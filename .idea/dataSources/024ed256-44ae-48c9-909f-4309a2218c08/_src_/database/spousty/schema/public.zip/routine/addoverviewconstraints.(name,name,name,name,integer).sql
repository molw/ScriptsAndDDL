CREATE FUNCTION addoverviewconstraints (ovtable name, ovcolumn name, reftable name, refcolumn name, ovfactor integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT AddOverviewConstraints('', $1, $2, '', $3, $4, $5) 
$$
