CREATE FUNCTION droprasterconstraints (rasttable name, rastcolumn name, VARIADIC constraints text[]) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT DropRasterConstraints('', $1, $2, VARIADIC $3) 
$$
