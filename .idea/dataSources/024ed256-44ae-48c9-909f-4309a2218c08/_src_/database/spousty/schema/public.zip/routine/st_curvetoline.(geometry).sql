CREATE FUNCTION st_curvetoline (geometry) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_CurveToLine($1, 32)
$$
