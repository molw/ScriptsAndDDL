CREATE FUNCTION st_disjoint (rast1 raster, nband1 integer, rast2 raster, nband2 integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT CASE WHEN $2 IS NULL OR $4 IS NULL THEN st_disjoint(st_convexhull($1), st_convexhull($3)) ELSE NOT _st_intersects($1, $2, $3, $4) END 
$$
