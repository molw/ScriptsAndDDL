CREATE FUNCTION st_quantile (rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT _st_quantile($1, 1, TRUE, 1, $2) 
$$
