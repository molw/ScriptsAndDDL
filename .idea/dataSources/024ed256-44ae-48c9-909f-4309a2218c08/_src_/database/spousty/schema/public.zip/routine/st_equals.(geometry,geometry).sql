CREATE FUNCTION st_equals (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 ~= $2 AND _ST_Equals($1,$2)
$$
