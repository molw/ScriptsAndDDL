CREATE FUNCTION st_quantile (rast raster, nband integer, exclude_nodata_value boolean, quantile double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (_st_quantile($1, $2, $3, 1, ARRAY[$4]::double precision[])).value 
$$
