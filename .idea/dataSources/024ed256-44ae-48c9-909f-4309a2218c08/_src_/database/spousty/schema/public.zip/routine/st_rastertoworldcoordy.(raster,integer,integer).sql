CREATE FUNCTION st_rastertoworldcoordy (rast raster, xr integer, yr integer) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT latitude FROM _st_rastertoworldcoord($1, $2, $3) 
$$
