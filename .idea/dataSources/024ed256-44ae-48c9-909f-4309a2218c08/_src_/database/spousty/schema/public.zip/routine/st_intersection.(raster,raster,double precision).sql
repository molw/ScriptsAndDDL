CREATE FUNCTION st_intersection (rast1 raster, rast2 raster, nodataval double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_intersection($1, 1, $2, 1, 'BOTH', ARRAY[$3, $3]) 
$$
