CREATE FUNCTION st_intersection (text, text) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT ST_Intersection($1::geometry, $2::geometry);  
$$
