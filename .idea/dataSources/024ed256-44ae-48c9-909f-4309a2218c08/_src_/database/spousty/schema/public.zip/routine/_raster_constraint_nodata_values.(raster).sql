CREATE FUNCTION _raster_constraint_nodata_values (rast raster) RETURNS numeric[]
	LANGUAGE sql
AS $$
 SELECT array_agg(round(nodatavalue::numeric, 10))::numeric[] FROM st_bandmetadata($1, ARRAY[]::int[]); 
$$
