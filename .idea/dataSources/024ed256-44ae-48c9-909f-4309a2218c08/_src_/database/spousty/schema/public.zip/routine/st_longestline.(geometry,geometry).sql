CREATE FUNCTION st_longestline (geom1 geometry, geom2 geometry) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT _ST_LongestLine(ST_ConvexHull($1), ST_ConvexHull($2))
$$
