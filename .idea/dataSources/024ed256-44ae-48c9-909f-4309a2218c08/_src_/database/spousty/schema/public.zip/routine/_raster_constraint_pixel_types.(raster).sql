CREATE FUNCTION _raster_constraint_pixel_types (rast raster) RETURNS text[]
	LANGUAGE sql
AS $$
 SELECT array_agg(pixeltype)::text[] FROM st_bandmetadata($1, ARRAY[]::int[]); 
$$
