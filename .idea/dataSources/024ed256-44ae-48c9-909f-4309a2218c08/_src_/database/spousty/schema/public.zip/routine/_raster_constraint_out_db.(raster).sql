CREATE FUNCTION _raster_constraint_out_db (rast raster) RETURNS boolean[]
	LANGUAGE sql
AS $$
 SELECT array_agg(isoutdb)::boolean[] FROM st_bandmetadata($1, ARRAY[]::int[]); 
$$
