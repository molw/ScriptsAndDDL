CREATE FUNCTION st_dwithin (rast1 raster, nband1 integer, rast2 raster, nband2 integer, distance double precision) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1::geometry && ST_Expand(ST_ConvexHull($3), $5) AND $3::geometry && ST_Expand(ST_ConvexHull($1), $5) AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN _st_dwithin(st_convexhull($1), st_convexhull($3), $5) ELSE _st_dwithin($1, $2, $3, $4, $5) END 
$$
