CREATE FUNCTION st_approxsummarystats (rastertable text, rastercolumn text, exclude_nodata_value boolean) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, 1, $3, 0.1) 
$$
