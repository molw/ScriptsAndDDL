CREATE FUNCTION _overview_constraint (ov raster, factor integer, refschema name, reftable name, refcolumn name) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT COALESCE((SELECT TRUE FROM raster_columns WHERE r_table_catalog = current_database() AND r_table_schema = $3 AND r_table_name = $4 AND r_raster_column = $5), FALSE) 
$$
