CREATE FUNCTION st_dfullywithin (geom1 geometry, geom2 geometry, double precision) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && ST_Expand($2,$3) AND $2 && ST_Expand($1,$3) AND _ST_DFullyWithin(ST_ConvexHull($1), ST_ConvexHull($2), $3)
$$
