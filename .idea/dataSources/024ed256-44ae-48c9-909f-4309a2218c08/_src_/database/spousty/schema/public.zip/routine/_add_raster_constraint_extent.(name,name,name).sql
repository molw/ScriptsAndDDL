CREATE FUNCTION _add_raster_constraint_extent (rastschema name, rasttable name, rastcolumn name) RETURNS boolean
	LANGUAGE plpgsql
AS $$
	DECLARE
		fqtn text;
		cn name;
		sql text;
		attr text;
	BEGIN
		fqtn := '';
		IF length($1) > 0 THEN
			fqtn := quote_ident($1) || '.';
		END IF;
		fqtn := fqtn || quote_ident($2);

		cn := 'enforce_max_extent_' || $3;

		sql := 'SELECT st_ashexewkb(st_envelope(st_collect(st_envelope('
			|| quote_ident($3)
			|| ')))) FROM '
			|| fqtn;
		EXECUTE sql INTO attr;

		sql := 'ALTER TABLE ' || fqtn
			|| ' ADD CONSTRAINT ' || quote_ident(cn)
			|| ' CHECK (st_envelope('
			|| quote_ident($3)
			|| ') @ ''' || attr || '''::geometry)';
		RETURN _add_raster_constraint(cn, sql);
	END;
	
$$
