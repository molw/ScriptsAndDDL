CREATE FUNCTION st_pixelofvalue (rast raster, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT x, y FROM st_pixelofvalue($1, 1, ARRAY[$2], $3) 
$$
