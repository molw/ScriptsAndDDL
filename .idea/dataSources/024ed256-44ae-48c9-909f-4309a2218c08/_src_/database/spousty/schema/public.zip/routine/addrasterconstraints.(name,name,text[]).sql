CREATE FUNCTION addrasterconstraints (rasttable name, rastcolumn name, VARIADIC constraints text[]) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT AddRasterConstraints('', $1, $2, VARIADIC $3) 
$$
