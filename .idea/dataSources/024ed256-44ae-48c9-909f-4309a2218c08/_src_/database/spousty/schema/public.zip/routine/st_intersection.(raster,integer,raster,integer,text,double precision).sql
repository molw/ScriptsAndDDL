CREATE FUNCTION st_intersection (rast1 raster, band1 integer, rast2 raster, band2 integer, returnband text, nodataval double precision) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_intersection($1, $2, $3, $4, $5, ARRAY[$6, $6]) 
$$
