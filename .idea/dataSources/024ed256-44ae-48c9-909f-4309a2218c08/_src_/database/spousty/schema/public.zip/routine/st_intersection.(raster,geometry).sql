CREATE FUNCTION st_intersection (rast raster, geomin geometry) RETURNS SETOF geomval
	LANGUAGE sql
AS $$
 SELECT st_intersection($2, $1, 1) 
$$
