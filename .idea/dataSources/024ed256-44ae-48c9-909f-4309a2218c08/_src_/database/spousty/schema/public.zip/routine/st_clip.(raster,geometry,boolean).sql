CREATE FUNCTION st_clip (rast raster, geom geometry, crop boolean) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT ST_Clip($1, NULL, $2, null::double precision[], $3) 
$$
