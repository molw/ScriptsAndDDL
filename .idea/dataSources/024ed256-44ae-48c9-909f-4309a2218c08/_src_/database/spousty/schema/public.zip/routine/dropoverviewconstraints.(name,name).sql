CREATE FUNCTION dropoverviewconstraints (ovtable name, ovcolumn name) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT DropOverviewConstraints('', $1, $2) 
$$
