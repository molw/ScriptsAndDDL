CREATE FUNCTION st_overlaps (rast1 raster, rast2 raster) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT st_overlaps($1, NULL::integer, $2, NULL::integer) 
$$
