CREATE FUNCTION st_geomfromgeohash (text, integer DEFAULT NULL::integer) RETURNS geometry
	LANGUAGE sql
AS $$
 SELECT CAST(ST_Box2dFromGeoHash($1, $2) AS geometry); 
$$
