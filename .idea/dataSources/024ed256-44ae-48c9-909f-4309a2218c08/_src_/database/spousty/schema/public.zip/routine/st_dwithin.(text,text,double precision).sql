CREATE FUNCTION st_dwithin (text, text, double precision) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT ST_DWithin($1::geometry, $2::geometry, $3);  
$$
