CREATE FUNCTION st_approxsummarystats (rastertable text, rastercolumn text, nband integer, sample_percent double precision) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, $2, $3, TRUE, $4) 
$$
