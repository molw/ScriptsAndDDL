CREATE FUNCTION st_asjpeg (rast raster, nband integer, quality integer) RETURNS bytea
	LANGUAGE sql
AS $$
 SELECT st_asjpeg($1, ARRAY[$2], $3) 
$$
