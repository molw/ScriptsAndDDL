CREATE FUNCTION st_geomcollfromtext (text, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE
	WHEN geometrytype(ST_GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN ST_GeomFromText($1,$2)
	ELSE NULL END
	
$$
