CREATE FUNCTION st_nearestvalue (rast raster, columnx integer, rowy integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT st_nearestvalue($1, 1, st_setsrid(st_makepoint(st_rastertoworldcoordx($1, $2, $3), st_rastertoworldcoordy($1, $2, $3)), st_srid($1)), $4) 
$$
