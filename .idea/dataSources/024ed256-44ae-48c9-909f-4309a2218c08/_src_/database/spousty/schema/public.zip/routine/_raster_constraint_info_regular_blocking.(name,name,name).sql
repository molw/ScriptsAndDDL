CREATE FUNCTION _raster_constraint_info_regular_blocking (rastschema name, rasttable name, rastcolumn name) RETURNS boolean
	LANGUAGE plpgsql
AS $$
	DECLARE
		covtile boolean;
		spunique boolean;
	BEGIN
		-- check existance of constraints
		-- coverage tile constraint
		covtile := COALESCE(_raster_constraint_info_coverage_tile($1, $2, $3), FALSE);

		-- spatially unique constraint
		spunique := COALESCE(_raster_constraint_info_spatially_unique($1, $2, $3), FALSE);

		RETURN (covtile AND spunique);
	END;
	
$$
