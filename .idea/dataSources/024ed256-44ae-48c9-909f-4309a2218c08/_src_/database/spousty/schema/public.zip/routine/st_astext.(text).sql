CREATE FUNCTION st_astext (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT ST_AsText($1::geometry);  
$$
