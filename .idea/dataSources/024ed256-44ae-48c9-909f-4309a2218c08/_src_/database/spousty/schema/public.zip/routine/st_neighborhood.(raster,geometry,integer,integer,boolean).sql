CREATE FUNCTION st_neighborhood (rast raster, pt geometry, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) RETURNS double precision[]
	LANGUAGE sql
AS $$
 SELECT st_neighborhood($1, 1, $2, $3, $4, $5) 
$$
